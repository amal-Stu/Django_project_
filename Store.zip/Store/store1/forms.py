from django import forms
from .models import Category
from .models import Stock, Shipping
class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = ['name']
        widgets = {
            'name': forms.Select(choices=Category.GENDER_CHOICES),
        }
from django import forms
from .models import Product

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'description', 'price', 'category', 'image']
        widgets = {
            'image': forms.ClearableFileInput(attrs={'multiple': False}),
        }




class StockForm(forms.ModelForm):
    class Meta:
        model = Stock
        fields = ['product', 'quantity']

class ShippingForm(forms.ModelForm):
    class Meta:
        model = Shipping
        fields = ['name', 'address']
