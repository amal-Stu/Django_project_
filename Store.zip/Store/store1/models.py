from django.db import models
from django.contrib.auth.models import AbstractUser
class CustomerUser(AbstractUser):
    phone_number = models.CharField(max_length=20)
    address = models.TextField()

    def __str__(self):
        return self.username

# هنا كلاس التصنيف اما رجالي او نسائي
class Category(models.Model):
    GENDER_CHOICES = [
        ('M', 'رجالي'),
        ('F', 'نسائي'),
    ]

    name = models.CharField(max_length=1, choices=GENDER_CHOICES, default='M')

    def __str__(self):
        return dict(self.GENDER_CHOICES).get(self.name, 'غير محدد')

class Product(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()  # Updated field name and type
    price = models.IntegerField()

    category = models.ForeignKey(Category, on_delete=models.CASCADE, default=1)  # استبدل '1' بقيمة افتراضية صحيحة
    image = models.ImageField(upload_to='product_images/', null=True, blank=True)  # حقل الصورة

    def __str__(self):
        return self.name



class Stock(models.Model):
    product = models.OneToOneField(Product, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=0)
    def __str__(self):
        return f"Stock for {self.product.name}"

class Shipping(models.Model):
    name = models.CharField(max_length=255)
    address = models.TextField()

    def __str__(self):
        return self.name
# تم استبداله ب cart
class Order(models.Model):
    customer = models.ForeignKey(CustomerUser, on_delete=models.CASCADE)
    shipping_address = models.ForeignKey(Shipping, on_delete=models.CASCADE)
    order_date = models.DateTimeField(auto_now_add=True)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"Order #{self.id} - {self.customer.username}"


# استبدلت بدالهلcartItem لكن ماراح احذفه
class OrderItem(models.Model):
    order = models.ForeignKey(Order, related_name='items', on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.IntegerField()
    price = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.quantity} x {self.product.name} in Order #{self.order.id}"


class Cart(models.Model):
    user = models.OneToOneField(CustomerUser, on_delete=models.CASCADE)

class CartItem(models.Model):
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE, related_name='items')
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)

