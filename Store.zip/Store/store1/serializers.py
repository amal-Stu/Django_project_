from rest_framework import serializers
from .models import CustomerUser, Category, Product, Stock, Shipping, Order, OrderItem

class CustomerUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomerUser
        fields = ['id', 'username', 'phone_number', 'address']


class CategorySerializer(serializers.ModelSerializer):
    gender_display = serializers.CharField(source='get_name_display', read_only=True)

    class Meta:
        model = Category
        fields = ['id', 'name', 'gender_display']

class ProductSerializer(serializers.ModelSerializer):
    category = CategorySerializer()

    class Meta:
        model = Product
        fields = ['id', 'name', 'description', 'price', 'category']

class StockSerializer(serializers.ModelSerializer):
    product = ProductSerializer()  # Nested serializer for product

    class Meta:
        model = Stock
        fields = ['id', 'product', 'quantity']

class ShippingSerializer(serializers.ModelSerializer):
    class Meta:
        model = Shipping
        fields = ['id', 'name', 'address']

class OrderSerializer(serializers.ModelSerializer):
    customer = CustomerUserSerializer()  # Nested serializer for customer
    shipping_address = ShippingSerializer()  # Nested serializer for shipping

    class Meta:
        model = Order
        fields = ['id', 'customer', 'shipping_address', 'order_date', 'total_amount']

class OrderItemSerializer(serializers.ModelSerializer):
    order = OrderSerializer()  # Nested serializer for order
    product = ProductSerializer()  # Nested serializer for product

    class Meta:
        model = OrderItem
        fields = ['id', 'order', 'product', 'quantity', 'price']
