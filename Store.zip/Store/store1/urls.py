
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth.views import LoginView
from .views import signup
from .views import (
    CustomerUserViewSet,
    CategoryViewSet,
    ProductViewSet,
    StockViewSet,
    ShippingViewSet,
    OrderViewSet,
cart_detail,
add_shipping,
    OrderItemViewSet,
    store,
    custom_logout,
    checkout_view,
update_shipping,
    process_checkout,
    view_cart,
    add_product,
    product_detail,
    product_list,
clear_cart,
main ,
view_shipping,
update_cart_item_quantity,
    add_to_cart
)

# إعداد الرواتر لواجهات برمجة التطبيقات
router = DefaultRouter()
router.register(r'customers', CustomerUserViewSet)
router.register(r'categories', CategoryViewSet)
router.register(r'products', ProductViewSet)
router.register(r'stocks', StockViewSet)
router.register(r'shippings', ShippingViewSet)
router.register(r'orders', OrderViewSet)
router.register(r'orderitems', OrderItemViewSet)

# تعريف المسارات
urlpatterns = [
    # مسارات العرض الأساسية
    path('login/', LoginView.as_view(template_name='store1/login.html'), name='login'),
    path('logout/', custom_logout, name='logout'),
    path('', main, name='main'),
    path('signup/', signup, name='signup'),  # تأكد من أن لديك View و Template للتسجيل
    path('store/', store, name='store'),  # المتجر الأساسي
    path('add-product/', add_product, name='product_create'),  # إضافة منتج
    path('product/<int:id>/', product_detail, name='product_detail'),  # تفاصيل المنتج
    path('product-list/', product_list, name='product_list'),  # قائمة المنتجات
    path('cart/', view_cart, name='view_cart'),
    path('cart_detail/', cart_detail, name='cart_detail'),
    path('add_to_cart/<int:product_id>/', add_to_cart, name='add_to_cart'),
    path('update_cart_item_quantity/<int:product_id>/', update_cart_item_quantity,
         name='update_cart_item_quantity'),
    path('clear_cart/', clear_cart, name='clear_cart'),

    path('checkout/', checkout_view, name='checkout'),  # صفحة الدفع
    path('process_checkout/', process_checkout, name='process_checkout'),  # معالجة الدفع
    path('view_shipping/', view_shipping, name='view_shipping'),
    path('shipping/add/', add_shipping, name='add_shipping'),
    path('shipping/update/<int:shipping_id>/', update_shipping, name='update_shipping'),
    # مسارات واجهات برمجة التطبيقات
    path('api/', include(router.urls)),
]

# إعدادات تحميل الملفات الإعلامية
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
