from pyexpat.errors import messages

from .forms import ProductForm, ShippingForm

from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth import login
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth import logout
from django.http import HttpResponse


def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            # يروح للمتجر بعد تسجيل الدخول
            return redirect('store')
    else:
        form = AuthenticationForm()
    return render(request, 'registration/login.html', {'form': form})

def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')  # بعد التسجيل ينقلني لصفحة تسجيل الدخول
    else:
        form = UserCreationForm()
    return render(request, 'store1/signup.html', {'form': form})



def custom_logout(request):
    logout(request)
    # بعد الخروج يمقلني لصفحة تسجيل الدخول
    return redirect('login')

# ميثود للستور تنقلني للستور الرئيسي
def store(request):
    user = request.user
    return render(request, 'main.html', {'user': user})

# ميثود تنقلني للصفحه الرئيسيه
def main(request):
    products = Product.objects.all()
    return render(request, 'main.html', {'products': products})

@login_required
# ميثود استخدمها لاضافة المنتجات يا من الادمن او من url الخاص فيها
def add_product(request):
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('product_list')  # عرض بعد الإضافة
    else:
        form = ProductForm()
    categories = Category.objects.all()
    return render(request, 'store1/add_product.html', {'form': form, 'categories': categories})




@login_required
def add_to_cart(request, product_id):
    # الحصول على المنتج بناءً على المعرف
    product = get_object_or_404(Product, id=product_id)
    user = request.user

    # احصل على السلة الخاصة بالمستخدم، أو أنشئ واحدة إذا لم تكن موجودة
    cart, created = Cart.objects.get_or_create(user=user)

    # محاولة الحصول على العنصر الموجود في السلة، أو إنشاء عنصر جديد إذا لم يكن موجودًا
    cart_item, created = CartItem.objects.get_or_create(
        cart=cart,
        product=product,
        defaults={'quantity': 1}
    )

    # إذا كان العنصر موجودًا بالفعل، قم بزيادة الكمية
    if not created:
        cart_item.quantity += 1
        cart_item.save()

    # طباعة معلومات للتأكد من التحقق من الأخطاء
    print(f"Cart ID: {cart.id}")
    print(f"Cart Item ID: {cart_item.id}")
    print(f"Cart Item Quantity: {cart_item.quantity}")

    # إعادة توجيه إلى صفحة السلة أو أي صفحة أخرى تفضلها
    return redirect('view_cart')  # تأكد من أن "view_cart" هو الاسم الصحيح للرابط الخاص بك

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Cart, CartItem, Product

@login_required
def clear_cart(request):
    if request.user.is_authenticated:
        try:
            cart = Cart.objects.filter(user=request.user).first()
            if cart:
                cart.items.all().delete()
                messages.success(request, 'تم مسح السلة بنجاح!')
            else:
                messages.info(request, 'السلة فارغة بالفعل.')
        except Exception as e:
            messages.error(request, f'حدث خطأ أثناء مسح السلة: {str(e)}')
    else:
        return redirect('login')
    return redirect('view_cart')


@login_required
def view_cart(request):
    cart = Cart.objects.filter(user=request.user).first()
    cart_items = cart.items.all() if cart else []

    # حساب الإجمالي
    total = sum(item.product.price * item.quantity for item in cart_items)

    return render(request, 'store1/cart.html', {
        'cart_items': cart_items,
        'total': total
    })

# لعرض تفاصيل السله
@login_required
def cart_detail(request):
    cart, created = Cart.objects.get_or_create(user=request.user)
    cart_items = CartItem.objects.filter(cart=cart)
    return render(request, 'store1/cart_detail.html', {'cart_items': cart_items})


# ميثود لتعديل الكميات بالسله
def update_cart_item_quantity(request, product_id):
    if request.user.is_authenticated:
        try:
            cart = Cart.objects.get(user=request.user)
            cart_item = CartItem.objects.get(cart=cart, product_id=product_id)
            new_quantity = int(request.POST.get('quantity', 1))
            cart_item.quantity = new_quantity
            cart_item.save()
        except CartItem.DoesNotExist:
            pass  # Handle the case where the cart item does not exist
    else:
        return redirect('login')
    return redirect('cart')

# قائمة المنتجات
def product_list(request):
    products = Product.objects.all()
    return render(request, 'store1/main.html', {'products': products})

# تفاصيل منتج معين
def product_detail(request, id):
    product = get_object_or_404(Product, id=id)
    context = {'product': product}
    return render(request, 'store1/product_detail.html', context)

# معالجة عملية الدفع
@csrf_exempt
def process_checkout(request):
    if request.method == 'POST':
        address = request.POST.get('address')
        payment_method = request.POST.get('payment')
        # معالجة الطلب وتخزين البيانات في قاعدة البيانات
        return HttpResponse('Checkout processed successfully!')
    return redirect('checkout')
def checkout_view(request):
    return render(request, 'store1/checkout.html')










def view_shipping(request):
    shippings = Shipping.objects.all()
    return render(request, 'store1/view_shipping.html', {'shippings': shippings})

def add_shipping(request):
    if request.method == 'POST':
        form = ShippingForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('view_shipping')
    else:
        form = ShippingForm()
    return render(request, 'store1/add_shipping.html', {'form': form})

def update_shipping(request, shipping_id):
    shipping = get_object_or_404(Shipping, id=shipping_id)
    if request.method == 'POST':
        form = ShippingForm(request.POST, instance=shipping)
        if form.is_valid():
            form.save()
            return redirect('view_shipping')
    else:
        form = ShippingForm(instance=shipping)
    return render(request, 'store1/update_shipping.html', {'form': form})









# تبع api ما راح استخدمه لكن احتفظ فيه لان سويناه بالبدايه
from rest_framework import viewsets
from .models import CustomerUser, Category, Product, Stock, Shipping, Order, OrderItem
from .serializers import CustomerUserSerializer, CategorySerializer, ProductSerializer, StockSerializer, ShippingSerializer, OrderSerializer, OrderItemSerializer

class CustomerUserViewSet(viewsets.ModelViewSet):
    queryset = CustomerUser.objects.all()
    serializer_class = CustomerUserSerializer

class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer

class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer

class StockViewSet(viewsets.ModelViewSet):
    queryset = Stock.objects.all()
    serializer_class = StockSerializer

class ShippingViewSet(viewsets.ModelViewSet):
    queryset = Shipping.objects.all()
    serializer_class = ShippingSerializer

class OrderViewSet(viewsets.ModelViewSet):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer

class OrderItemViewSet(viewsets.ModelViewSet):
    queryset = OrderItem.objects.all()
    serializer_class = OrderItemSerializer
